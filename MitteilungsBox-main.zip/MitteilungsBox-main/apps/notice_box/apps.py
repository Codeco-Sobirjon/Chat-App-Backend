from django.apps import AppConfig


class NoticeBoxConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.notice_box'
