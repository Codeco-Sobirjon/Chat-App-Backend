import MitteilungTable from '../components/MitteilungTable';

const LinksBar = () => {
  return (
    <div className='p-2'>
      <MitteilungTable />
    </div>
  );
};

export default LinksBar;
