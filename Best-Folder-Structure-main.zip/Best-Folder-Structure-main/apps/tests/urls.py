from django.urls import path

urlpatterns = [

]