import { View, Text } from "react-native";
import React from "react";

const UserProfile = () => {
  return (
    <View>
      <Text>User Profie</Text>
    </View>
  );
};

export default UserProfile;
