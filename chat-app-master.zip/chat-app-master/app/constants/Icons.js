export const iconSize = {
  icon_md: 24,
  icon_sm: 22,
  icon_xsm: 16,
};
