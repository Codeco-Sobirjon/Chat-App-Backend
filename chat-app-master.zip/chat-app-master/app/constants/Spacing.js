export const spacing = {
  spacing_lg: 30,
  spacing_md: 20,
  spacing_sx: 10,
  spacing_sm: 5,
};
