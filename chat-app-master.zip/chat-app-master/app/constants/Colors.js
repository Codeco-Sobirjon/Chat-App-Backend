export const colors = {
  color_white: "#fff",
  color_light: "#878787",
  color_light_secondary: "#EFEFEF",
  color_yellow: "#FFC300",
};
