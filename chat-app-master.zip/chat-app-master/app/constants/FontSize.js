export const fontSize = {
  font_size_2xl: 26,
  font_size_xl: 22,
  font_size_lg: 18,
  font_size_md: 16,
  font_size_sm: 12,
};
