SPECTACULAR_SETTINGS = {
    "TITLE": "Mal dex backend",
    "DESCRIPTION": "Mal dex backend",
    "VERSION": "0.1.0"
}
