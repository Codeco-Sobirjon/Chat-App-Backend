def get_filename(filename, request):
    return filename.upper()