from django.contrib import admin
from apps.notification.models import (
    Notification
)


admin.site.register(Notification)
