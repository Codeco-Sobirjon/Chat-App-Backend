from random import randint

# It is a function that generates a random number between 100000 and 999999
def generate_sms_code():
    return randint(100000, 999999)